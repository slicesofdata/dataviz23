# Run script to setup R libraries
# This might take a minute to complete.
source("https://www.dropbox.com/s/vzobyji59l0zfa5/startup_packages.R?raw=1")