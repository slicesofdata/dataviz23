# Run this script to obtain files for Exercise/HW 1

# Check to make sure your working directory is correct. If not, correct it before proceeding.
getwd() # should be the path to your Desktop

# Get Homework file(s)
source("https://www.dropbox.com/s/djqigycg0q7oits/sourceExercise1.R?raw=1")

# After running the code, close this file and open the script file. 